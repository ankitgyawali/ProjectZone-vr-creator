1. Subfolder "Assign 3 - Texture" fullfills the texture and tinting requirements.
2. Main outer folder's index.html fullfills the PShape requirement also. Spheres were combined inside a loop to create  single mesh before animating it.
3. The freeze key "f" works for both index files while the demo "d" key works for inner subdirectory's index.html only.
4. Can also be found at: sftp://acad.kutztown.edu/www/student/agyaw792/220/Assign3
------------------------
My experience with Three.js
---
Three JS uses 3 main things -> Scene, Camera, Renderer
Scene -> Main scene where objects are places
Camera -> Type of camera (a robot eye) that can be placed anywhere in the scence to view
Renderer -> Runs at specified framerate to render scence

Three JS objects consist of 3 main things -> Geometry, Material, Mesh
Geometry -> Defines geometry of object. Can be pre defined geometry or vertices co-ordinates imoprted from external files created softwares like adobe illustrator and blender.
Material -> A 'skin' to wrap around that geometry. Can be color, textures or videos rendered as image at the rate of framerate.
Mesh -> Final object ready to be placed inside scene. Complex meshes can be created by combining geometries and materials. Meshes are the final objects that are animated, translated etc. in the scene.


